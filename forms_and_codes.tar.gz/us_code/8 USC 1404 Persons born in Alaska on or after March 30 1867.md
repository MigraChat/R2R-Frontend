<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1404&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:51
-->
### §1404\. Persons born in Alaska on or after March 30, 1867
 A person born in Alaska on or after March 30, 1867, except a noncitizen Indian, is a citizen of the United States at birth. A noncitizen Indian born in Alaska on or after March 30, 1867, and prior to June 2, 1924, is declared to be a citizen of the United States as of June 2, 1924\. An Indian born in Alaska on or after June 2, 1924, is a citizen of the United States at birth.
 (
 June 27, 1952, ch. 477, title III, ch. 1, §304,
 66 Stat. 237
 .)
#### **Statutory Notes and Related Subsidiaries**
#### Admission of Alaska as State
 Alaska Statehood provisions as not repealing, amending, or modifying the provisions of this section, see section 24 of
 Pub. L. 85–508,
 July 7, 1958,
 72 Stat. 339
 , set out as a note preceding former
 section 21 of Title 48
 , Territories and Insular Possessions.
