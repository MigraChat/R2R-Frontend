<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1434&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:57
-->
### §1434\. Repealed.
 Pub. L. 95–417,
 §7, Oct. 5, 1978,
 92 Stat. 918
 Section, acts
 June 27, 1952, ch. 477, title III, ch. 2, §323,
 66 Stat. 246
 ; Sept. 11, 1957,
 Pub. L. 85–316,
 §11,
 71 Stat. 642
 ; Aug. 20, 1958,
 Pub. L. 85–697,
 §1,
 72 Stat. 687
 , related to citizenship of children adopted by citizens.
