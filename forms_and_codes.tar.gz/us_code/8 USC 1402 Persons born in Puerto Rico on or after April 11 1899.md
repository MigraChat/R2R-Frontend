<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1402&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:51
-->
### §1402\. Persons born in Puerto Rico on or after April 11, 1899
 All persons born in Puerto Rico on or after April 11, 1899, and prior to January 13, 1941, subject to the jurisdiction of the United States, residing on January 13, 1941, in Puerto Rico or other territory over which the United States exercises rights of sovereignty and not citizens of the United States under any other Act, are declared to be citizens of the United States as of January 13, 1941\. All persons born in Puerto Rico on or after January 13, 1941, and subject to the jurisdiction of the United States, are citizens of the United States at birth.
 (
 June 27, 1952, ch. 477, title III, ch. 1, §302,
 66 Stat. 236
 .)
