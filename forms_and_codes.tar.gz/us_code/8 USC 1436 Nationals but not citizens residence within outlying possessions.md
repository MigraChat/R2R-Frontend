<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1436&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:58
-->
### §1436\. Nationals but not citizens; residence within outlying possessions
 A person not a citizen who owes permanent allegiance to the United States, and who is otherwise qualified, may, if he becomes a resident of any State, be naturalized upon compliance with the applicable requirements of this subchapter, except that in applications for naturalization filed under the provisions of this section residence and physical presence within the United States within the meaning of this subchapter shall include residence and physical presence within any of the outlying possessions of the United States.
 (
 June 27, 1952, ch. 477, title III, ch. 2, §325,
 66 Stat. 248
 ;
 Pub. L. 101–649,
 title IV, §407(c)(8\), Nov. 29, 1990,
 104 Stat. 5041
 .)
#### **Editorial Notes**
#### Amendments
**1990** 
 \-
 Pub. L. 101–649
 substituted "applications" for "petitions".
