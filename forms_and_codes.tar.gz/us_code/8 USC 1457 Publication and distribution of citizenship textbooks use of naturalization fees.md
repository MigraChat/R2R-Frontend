<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1457&num=0&edition=prelim
date_accessed: 2024-07-28 23:46:05
-->
### §1457\. Publication and distribution of citizenship textbooks; use of naturalization fees
 Authorization is granted for the publication and distribution of the citizenship textbook described in subsection (b) of
 section 1443 of this title
 and for the reimbursement of the appropriation of the Department of Justice upon the records of the Treasury Department from the naturalization fees deposited in the Treasury through the Service for the cost of such publication and distribution, such reimbursement to be made upon statements by the Attorney General of books so published and distributed.
 (
 June 27, 1952, ch. 477, title III, ch. 2, §346,
 66 Stat. 266
 .)
#### **Statutory Notes and Related Subsidiaries**
#### Abolition of Immigration and Naturalization Service and Transfer of Functions
 For abolition of Immigration and Naturalization Service, transfer of functions, and treatment of related references, see note set out under
 section 1551 of this title
 .
