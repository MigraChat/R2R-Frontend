<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1437&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:58
-->
### §1437\. Resident Philippine citizens excepted from certain requirements
 Any person who (1\) was a citizen of the Commonwealth of the Philippines on July 2, 1946, (2\) entered the United States prior to May 1, 1934, and (3\) has, since such entry, resided continuously in the United States shall be regarded as having been lawfully admitted to the United States for permanent residence for the purpose of applying for naturalization under this subchapter.
 (
 June 27, 1952, ch. 477, title III, ch. 2, §326,
 66 Stat. 248
 ;
 Pub. L. 101–649,
 title IV, §407(c)(9\), Nov. 29, 1990,
 104 Stat. 5041
 .)
#### **Editorial Notes**
#### Amendments
**1990** 
 \-
 Pub. L. 101–649
 substituted "applying" for "petitioning".
