<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1422&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:53
-->
### §1422\. Eligibility for naturalization
 The right of a person to become a naturalized citizen of the United States shall not be denied or abridged because of race or sex or because such person is married.
 (
 June 27, 1952, ch. 477, title III, ch. 2, §311,
 66 Stat. 239
 ;
 Pub. L. 100–525,
 §9(t), Oct. 24, 1988,
 102 Stat. 2621
 .)
#### **Editorial Notes**
#### Amendments
**1988** 
 \-
 Pub. L. 100–525
 struck out at end "Notwithstanding section 405(b) of this Act, this section shall apply to any person whose petition for naturalization shall hereafter be filed, or shall have been pending on the effective date of this chapter."
