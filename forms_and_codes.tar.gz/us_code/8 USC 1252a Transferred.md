<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1252a&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:31
-->
### §1252a. Transferred
#### **Editorial Notes**
#### Codification
 Section 1252a, act June 27, 1952, ch. 477, title II, ch. 5, §242A, as added Nov. 18, 1988,
 Pub. L. 100–690,
 title VII, §7347(a),
 102 Stat. 4471
 , as amended, which related to expedited removal of aliens convicted of committing aggravated felonies, was renumbered section 238 of ch. 4 of title II of act June 27, 1952, by
 Pub. L. 104–208,
 div. C, title III, §308(b)(5\), Sept. 30, 1996,
 110 Stat. 3009–615
 , and was transferred to
 section 1228 of this title
 .
