<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1459&num=0&edition=prelim
date_accessed: 2024-07-28 23:46:06
-->
### §1459\. Repealed.
 Pub. L. 101–649,
 title IV, §407(d)(20\), Nov. 29, 1990,
 104 Stat. 5046
 Section, acts
 June 27, 1952, ch. 477, title III, ch. 2, §348,
 66 Stat. 267
 ; Oct. 24, 1988,
 Pub. L. 100–525,
 §9(gg),
 102 Stat. 2622
 , related to admissibility in evidence of statements voluntarily made to officers and employees in course of their official duties and penalties for failure of clerk of court to perform duties.
