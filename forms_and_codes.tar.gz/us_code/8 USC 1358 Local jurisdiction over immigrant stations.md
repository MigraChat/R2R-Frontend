<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1358&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:48
-->
### §1358\. Local jurisdiction over immigrant stations
 The officers in charge of the various immigrant stations shall admit therein the proper State and local officers charged with the enforcement of the laws of the State or Territory of the United States in which any such immigrant station is located in order that such State and local officers may preserve the peace and make arrests for crimes under the laws of the States and Territories. For the purpose of this section the jurisdiction of such State and local officers and of the State and local courts shall extend over such immigrant stations.
 (
 June 27, 1952, ch. 477, title II, ch. 9, §288,
 66 Stat. 234
 .)
