<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1456&num=0&edition=prelim
date_accessed: 2024-07-28 23:46:05
-->
### §1456\. Repealed.
 Pub. L. 86–682,
 §12(c), Sept. 2, 1960,
 74 Stat. 708
 , eff. Sept. 1, 1960
 Section, act
 June 27, 1952, ch. 477, title III, ch. 2, §345,
 66 Stat. 266
 , related to free transmittal of official mail in naturalization matters. See
 section 3202 of Title 39
 , Postal Service.
