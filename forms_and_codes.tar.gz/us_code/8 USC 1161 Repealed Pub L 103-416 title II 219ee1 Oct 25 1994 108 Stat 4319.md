<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1161&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:17
-->
### §1161\. Repealed.
 Pub. L. 103–416,
 title II, §219(ee)(1\), Oct. 25, 1994,
 108 Stat. 4319
 Section, act June 27, 1952, ch. 477, title II, ch. 1, §210A, as added Nov. 6, 1986,
 Pub. L. 99–603,
 title III, §303(a),
 100 Stat. 3422
 ; amended Oct. 24, 1988,
 Pub. L. 100–525,
 §2(n)(1\),
 102 Stat. 2613
 ; Nov. 29, 1990,
 Pub. L. 101–649,
 title VI, §603(a)(6\), (b)(1\),
 104 Stat. 5083
 ,
 5085 
 ; Dec. 12, 1991,
 Pub. L. 102–232,
 title III, §307(l)(2\),
 105 Stat. 1756
 , related to determination of agricultural labor shortages and admission of additional special agricultural workers.
#### **Statutory Notes and Related Subsidiaries**
#### Effective Date of Repeal
 Pub. L. 103–416,
 title II, §219(ee)(3\), as added by
 Pub. L. 104–208,
 div. C, title VI, §671(b)(10\), Sept. 30, 1996,
 110 Stat. 3009–722
 , provided that: "The amendments made by this subsection \[repealing this section] shall take effect on the date of the enactment of this Act \[Oct. 25, 1994]."
