<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1405&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:52
-->
### §1405\. Persons born in Hawaii
 A person born in Hawaii on or after August 12, 1898, and before April 30, 1900, is declared to be a citizen of the United States as of April 30, 1900\. A person born in Hawaii on or after April 30, 1900, is a citizen of the United States at birth. A person who was a citizen of the Republic of Hawaii on August 12, 1898, is declared to be a citizen of the United States as of April 30, 1900\.
 (
 June 27, 1952, ch. 477, title III, ch. 1, §305,
 66 Stat. 237
 .)
#### **Executive Documents**
#### Admission of Hawaii as State
 Hawaii Statehood provisions as not repealing, amending, or modifying the provisions of this section, see section 20 of
 Pub. L. 86–3,
 Mar. 18, 1959,
 73 Stat. 13
 , set out as a note at the beginning of
 chapter 3 of Title 48
 , Territories and Insular Possessions.
