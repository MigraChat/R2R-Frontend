<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1488&num=0&edition=prelim
date_accessed: 2024-07-28 23:46:08
-->
### §1488\. Nationality lost solely from performance of acts or fulfillment of conditions
 The loss of nationality under this part shall result solely from the performance by a national of the acts or fulfillment of the conditions specified in this part.
 (
 June 27, 1952, ch. 477, title III, ch. 3, §356,
 66 Stat. 272
 .)
