<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1252b&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:31
-->
### §1252b. Repealed.
 Pub. L. 104–208,
 div. C, title III, §308(b)(6\), Sept. 30, 1996,
 110 Stat. 3009–615
 Section, act June 27, 1952, ch. 477, title II, ch. 5, §242B, as added Nov. 29, 1990,
 Pub. L. 101–649,
 title V, §545(a),
 104 Stat. 5061
 ; amended Dec. 12, 1991,
 Pub. L. 102–232,
 title III, §306(c)(6\),
 105 Stat. 1753
 ; Oct. 25, 1994,
 Pub. L. 103–416,
 title II, §219(i),
 108 Stat. 4317
 ; Sept. 30, 1996,
 Pub. L. 104–208,
 div. C, title III, §371(b)(7\),
 110 Stat. 3009–645
 , related to deportation procedures. See
 sections 1229 and 1229a of this title
 .
#### **Statutory Notes and Related Subsidiaries**
#### Effective Date of Repeal
 Repeal effective, with certain transitional provisions, on the first day of the first month beginning more than 180 days after Sept. 30, 1996, see section 309 of
 Pub. L. 104–208,
 set out as an Effective Date of 1996 Amendments note under
 section 1101 of this title
 .
