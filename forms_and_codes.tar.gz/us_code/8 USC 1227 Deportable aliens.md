<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1227&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:27
-->
### §1227\. Deportable aliens
#### (a) Classes of deportable aliens
 Any alien (including an alien crewman) in and admitted to the United States shall, upon the order of the Attorney General, be removed if the alien is within one or more of the following classes of deportable aliens:
#### (1\) Inadmissible at time of entry or of adjustment of status or violates status
#### (A) Inadmissible aliens
 Any alien who at the time of entry or adjustment of status was within one or more of the classes of aliens inadmissible by the law existing at such time is deportable.
#### (B) Present in violation of law
 Any alien who is present in the United States in violation of this chapter or any other law of the United States, or whose nonimmigrant visa (or other documentation authorizing admission into the United States as a nonimmigrant) has been revoked under
 section 1201(i) of this title
 , is deportable.
#### (C) Violated nonimmigrant status or condition of entry
#### (i) Nonimmigrant status violators
 Any alien who was admitted as a nonimmigrant and who has failed to maintain the nonimmigrant status in which the alien was admitted or to which it was changed under
 section 1258 of this title
 , or to comply with the conditions of any such status, is deportable.
#### (ii) Violators of conditions of entry
 Any alien whom the Secretary of Health and Human Services certifies has failed to comply with terms, conditions, and controls that were imposed under
 section 1182(g) of this title
 is deportable.
#### (D) Termination of conditional permanent residence
#### (i) In general
 Any alien with permanent resident status on a conditional basis under
 section 1186a of this title
 (relating to conditional permanent resident status for certain alien spouses and sons and daughters) or under
 section 1186b of this title
 (relating to conditional permanent resident status for certain alien entrepreneurs, spouses, and children) who has had such status terminated under such respective section is deportable.
#### (ii) Exception
 Clause (i) shall not apply in the cases described in
 section 1186a(c)(4\) of this title
 (relating to certain hardship waivers).
#### (E) Smuggling
#### (i) In general
 Any alien who (prior to the date of entry, at the time of any entry, or within 5 years of the date of any entry) knowingly has encouraged, induced, assisted, abetted, or aided any other alien to enter or to try to enter the United States in violation of law is deportable.
#### (ii) Special rule in the case of family reunification
 Clause (i) shall not apply in the case of alien who is an eligible immigrant (as defined in section 301(b)(1\) of the Immigration Act of 1990\), was physically present in the United States on May 5, 1988, and is seeking admission as an immediate relative or under
 section 1153(a)(2\) of this title
 (including under section 112 of the Immigration Act of 1990\) or benefits under section 301(a) of the Immigration Act of 1990 if the alien, before May 5, 1988, has encouraged, induced, assisted, abetted, or aided only the alien's spouse, parent, son, or daughter (and no other individual) to enter the United States in violation of law.
#### (iii) Waiver authorized
 The Attorney General may, in his discretion for humanitarian purposes, to assure family unity, or when it is otherwise in the public interest, waive application of clause (i) in the case of any alien lawfully admitted for permanent residence if the alien has encouraged, induced, assisted, abetted, or aided only an individual who at the time of the offense was the alien's spouse, parent, son, or daughter (and no other individual) to enter the United States in violation of law.
#### (F) Repealed.
 Pub. L. 104–208,
 div. C, title VI, §671(d)(1\)(C), Sept. 30, 1996,
 110 Stat. 3009–723
#### (G) Marriage fraud
 An alien shall be considered to be deportable as having procured a visa or other documentation by fraud (within the meaning of
 section 1182(a)(6\)(C)(i) of this title
 ) and to be in the United States in violation of this chapter (within the meaning of subparagraph (B)) if\-
 (i) the alien obtains any admission into the United States with an immigrant visa or other documentation procured on the basis of a marriage entered into less than 2 years prior to such admission of the alien and which, within 2 years subsequent to any admission of the alien in the United States, shall be judicially annulled or terminated, unless the alien establishes to the satisfaction of the Attorney General that such marriage was not contracted for the purpose of evading any provisions of the immigration laws, or
 (ii) it appears to the satisfaction of the Attorney General that the alien has failed or refused to fulfill the alien's marital agreement which in the opinion of the Attorney General was made for the purpose of procuring the alien's admission as an immigrant.
#### (H) Waiver authorized for certain misrepresentations
 The provisions of this paragraph relating to the removal of aliens within the United States on the ground that they were inadmissible at the time of admission as aliens described in
 section 1182(a)(6\)(C)(i) of this title
 , whether willful or innocent, may, in the discretion of the Attorney General, be waived for any alien (other than an alien described in paragraph (4\)(D)) who\-
 (i)(I) is the spouse, parent, son, or daughter of a citizen of the United States or of an alien lawfully admitted to the United States for permanent residence; and
 (II) was in possession of an immigrant visa or equivalent document and was otherwise admissible to the United States at the time of such admission except for those grounds of inadmissibility specified under paragraphs (5\)(A) and (7\)(A) of
 section 1182(a) of this title
 which were a direct result of that fraud or misrepresentation.
 (ii) is a VAWA self\-petitioner.
 A waiver of removal for fraud or misrepresentation granted under this subparagraph shall also operate to waive removal based on the grounds of inadmissibility directly resulting from such fraud or misrepresentation.
#### (2\) Criminal offenses
#### (A) General crimes
#### (i) Crimes of moral turpitude
 Any alien who\-
 (I) is convicted of a crime involving moral turpitude committed within five years (or 10 years in the case of an alien provided lawful permanent resident status under
 section 1255(j) of this title
 ) after the date of admission, and
 (II) is convicted of a crime for which a sentence of one year or longer may be imposed,
 is deportable.
#### (ii) Multiple criminal convictions
 Any alien who at any time after admission is convicted of two or more crimes involving moral turpitude, not arising out of a single scheme of criminal misconduct, regardless of whether confined therefor and regardless of whether the convictions were in a single trial, is deportable.
#### (iii) Aggravated felony
 Any alien who is convicted of an aggravated felony at any time after admission is deportable.
#### (iv) High speed flight
 Any alien who is convicted of a violation of
 section 758 of title 18
 (relating to high speed flight from an immigration checkpoint) is deportable.
#### (v) Failure to register as a sex offender
 Any alien who is convicted under
 section 2250 of title 18
 is deportable.
#### (vi) Waiver authorized
 Clauses (i), (ii), (iii), and (iv) shall not apply in the case of an alien with respect to a criminal conviction if the alien subsequent to the criminal conviction has been granted a full and unconditional pardon by the President of the United States or by the Governor of any of the several States.
#### (B) Controlled substances
#### (i) Conviction
 Any alien who at any time after admission has been convicted of a violation of (or a conspiracy or attempt to violate) any law or regulation of a State, the United States, or a foreign country relating to a controlled substance (as defined in
 section 802 of title 21
 ), other than a single offense involving possession for one's own use of 30 grams or less of marijuana, is deportable.
#### (ii) Drug abusers and addicts
 Any alien who is, or at any time after admission has been, a drug abuser or addict is deportable.
#### (C) Certain firearm offenses
 Any alien who at any time after admission is convicted under any law of purchasing, selling, offering for sale, exchanging, using, owning, possessing, or carrying, or of attempting or conspiring to purchase, sell, offer for sale, exchange, use, own, possess, or carry, any weapon, part, or accessory which is a firearm or destructive device (as defined in
 section 921(a) of title 18
 ) in violation of any law is deportable.
#### (D) Miscellaneous crimes
 Any alien who at any time has been convicted (the judgment on such conviction becoming final) of, or has been so convicted of a conspiracy or attempt to violate\-
 (i) any offense under
 chapter 37
 (relating to espionage),
 chapter 105
 (relating to sabotage), or
 chapter 115 (relating to treason and sedition) of title 18
 for which a term of imprisonment of five or more years may be imposed;
 (ii) any offense under
 section 871 or 960 of title 18
 ;
 (iii) a violation of any provision of the Military Selective Service Act (
 50 U.S.C. App. 451 et seq.
 ) \[now
 50 U.S.C. 3801 et seq.
 ] or the Trading With the Enemy Act (
 50 U.S.C. App. 1 et seq.
 ) \[now
 50 U.S.C. 4301 et seq.
 ]; or
 (iv) a violation of
 section 1185 or 1328 of this title
 ,
 is deportable.
#### (E) Crimes of domestic violence, stalking, or violation of protection order, crimes against children and
#### (i) Domestic violence, stalking, and child abuse
 Any alien who at any time after admission is convicted of a crime of domestic violence, a crime of stalking, or a crime of child abuse, child neglect, or child abandonment is deportable. For purposes of this clause, the term "crime of domestic violence" means any crime of violence (as defined in
 section 16 of title 18
 ) against a person committed by a current or former spouse of the person, by an individual with whom the person shares a child in common, by an individual who is cohabiting with or has cohabited with the person as a spouse, by an individual similarly situated to a spouse of the person under the domestic or family violence laws of the jurisdiction where the offense occurs, or by any other individual against a person who is protected from that individual's acts under the domestic or family violence laws of the United States or any State, Indian tribal government, or unit of local government.
#### (ii) Violators of protection orders
 Any alien who at any time after admission is enjoined under a protection order issued by a court and whom the court determines has engaged in conduct that violates the portion of a protection order that involves protection against credible threats of violence, repeated harassment, or bodily injury to the person or persons for whom the protection order was issued is deportable. For purposes of this clause, the term "protection order" means any injunction issued for the purpose of preventing violent or threatening acts of domestic violence, including temporary or final orders issued by civil or criminal courts (other than support or child custody orders or provisions) whether obtained by filing an independent action or as a pendente lite order in another proceeding.
#### (F) Trafficking
 Any alien described in
 section 1182(a)(2\)(H) of this title
 is deportable.
#### (3\) Failure to register and falsification of documents
#### (A) Change of address
 An alien who has failed to comply with the provisions of
 section 1305 of this title
 is deportable, unless the alien establishes to the satisfaction of the Attorney General that such failure was reasonably excusable or was not willful.
#### (B) Failure to register or falsification of documents
 Any alien who at any time has been convicted\-
 (i) under
 section 1306(c) of this title
 or under section 36(c) of the Alien Registration Act, 1940,
 (ii) of a violation of, or an attempt or a conspiracy to violate, any provision of the Foreign Agents Registration Act of 1938 (
 22 U.S.C. 611 et seq.
 ), or
 (iii) of a violation of, or an attempt or a conspiracy to violate,
 section 1546 of title 18
 (relating to fraud and misuse of visas, permits, and other entry documents),
 is deportable.
#### (C) Document fraud
#### (i) In general
 An alien who is the subject of a final order for violation of
 section 1324c of this title
 is deportable.
#### (ii) Waiver authorized
 The Attorney General may waive clause (i) in the case of an alien lawfully admitted for permanent residence if no previous civil money penalty was imposed against the alien under
 section 1324c of this title
 and the offense was incurred solely to assist, aid, or support the alien's spouse or child (and no other individual). No court shall have jurisdiction to review a decision of the Attorney General to grant or deny a waiver under this clause.
#### (D) Falsely claiming citizenship
#### (i) In general
 Any alien who falsely represents, or has falsely represented, himself to be a citizen of the United States for any purpose or benefit under this chapter (including
 section 1324a of this title
 ) or any Federal or State law is deportable.
#### (ii) Exception
 In the case of an alien making a representation described in clause (i), if each natural parent of the alien (or, in the case of an adopted alien, each adoptive parent of the alien) is or was a citizen (whether by birth or naturalization), the alien permanently resided in the United States prior to attaining the age of 16, and the alien reasonably believed at the time of making such representation that he or she was a citizen, the alien shall not be considered to be deportable under any provision of this subsection based on such representation.
#### (4\) Security and related grounds
#### (A) In general
 Any alien who has engaged, is engaged, or at any time after admission engages in\-
 (i) any activity to violate any law of the United States relating to espionage or sabotage or to violate or evade any law prohibiting the export from the United States of goods, technology, or sensitive information,
 (ii) any other criminal activity which endangers public safety or national security, or
 (iii) any activity a purpose of which is the opposition to, or the control or overthrow of, the Government of the United States by force, violence, or other unlawful means,
 is deportable.
#### (B) Terrorist activities
 Any alien who is described in subparagraph (B) or (F) of
 section 1182(a)(3\) of this title
 is deportable.
#### (C) Foreign policy
#### (i) In general
 An alien whose presence or activities in the United States the Secretary of State has reasonable ground to believe would have potentially serious adverse foreign policy consequences for the United States is deportable.
#### (ii) Exceptions
 The exceptions described in clauses (ii) and (iii) of
 section 1182(a)(3\)(C) of this title
 shall apply to deportability under clause (i) in the same manner as they apply to inadmissibility under
 section 1182(a)(3\)(C)(i) of this title
 .
#### (D) Participated in Nazi persecution, genocide, or the commission of any act of torture or extrajudicial killing
 Any alien described in clause (i), (ii), or (iii) of
 section 1182(a)(3\)(E) of this title
 is deportable.
#### (E) Participated in the commission of severe violations of religious freedom
 Any alien described in
 section 1182(a)(2\)(G) of this title
 is deportable.
#### (F) Recruitment or use of child soldiers
 Any alien who has engaged in the recruitment or use of child soldiers in violation of
 section 2442 of title 18
 is deportable.
#### (5\) Public charge
 Any alien who, within five years after the date of entry, has become a public charge from causes not affirmatively shown to have arisen since entry is deportable.
#### (6\) Unlawful voters
#### (A) In general
 Any alien who has voted in violation of any Federal, State, or local constitutional provision, statute, ordinance, or regulation is deportable.
#### (B) Exception
 In the case of an alien who voted in a Federal, State, or local election (including an initiative, recall, or referendum) in violation of a lawful restriction of voting to citizens, if each natural parent of the alien (or, in the case of an adopted alien, each adoptive parent of the alien) is or was a citizen (whether by birth or naturalization), the alien permanently resided in the United States prior to attaining the age of 16, and the alien reasonably believed at the time of such violation that he or she was a citizen, the alien shall not be considered to be deportable under any provision of this subsection based on such violation.
#### (7\) Waiver for victims of domestic violence
#### (A) In general
 The Attorney General is not limited by the criminal court record and may waive the application of paragraph (2\)(E)(i) (with respect to crimes of domestic violence and crimes of stalking) and (ii) in the case of an alien who has been battered or subjected to extreme cruelty and who is not and was not the primary perpetrator of violence in the relationship\-
 (i)
 1
 upon a determination that\-
 (I) the alien was acting is
 2
 self\-defense;
 (II) the alien was found to have violated a protection order intended to protect the alien; or
 (III) the alien committed, was arrested for, was convicted of, or pled guilty to committing a crime\-
 (aa) that did not result in serious bodily injury; and
 (bb) where there was a connection between the crime and the alien's having been battered or subjected to extreme cruelty.
#### (B) Credible evidence considered
 In acting on applications under this paragraph, the Attorney General shall consider any credible evidence relevant to the application. The determination of what evidence is credible and the weight to be given that evidence shall be within the sole discretion of the Attorney General.
#### (b) Deportation of certain nonimmigrants
 An alien, admitted as a nonimmigrant under the provisions of either
 section 1101(a)(15\)(A)(i) or 1101(a)(15\)(G)(i) of this title
 , and who fails to maintain a status under either of those provisions, shall not be required to depart from the United States without the approval of the Secretary of State, unless such alien is subject to deportation under paragraph (4\) of subsection (a).
#### (c) Waiver of grounds for deportation
 Paragraphs (1\)(A), (1\)(B), (1\)(C), (1\)(D), and (3\)(A) of subsection (a) (other than so much of paragraph (1\) as relates to a ground of inadmissibility described in paragraph (2\) or (3\) of
 section 1182(a) of this title
 ) shall not apply to a special immigrant described in
 section 1101(a)(27\)(J) of this title
 based upon circumstances that existed before the date the alien was provided such special immigrant status.
#### (d) Administrative stay
 (1\) If the Secretary of Homeland Security determines that an application for nonimmigrant status under subparagraph (T) or (U) of
 section 1101(a)(15\) of this title
 filed for an alien in the United States sets forth a prima facie case for approval, the Secretary may grant the alien an administrative stay of a final order of removal under
 section 1231(c)(2\) of this title
 until\-
 (A) the application for nonimmigrant status under such subparagraph (T) or (U) is approved; or
 (B) there is a final administrative denial of the application for such nonimmigrant status after the exhaustion of administrative appeals.
 (2\) The denial of a request for an administrative stay of removal under this subsection shall not preclude the alien from applying for a stay of removal, deferred action, or a continuance or abeyance of removal proceedings under any other provision of the immigration laws of the United States.
 (3\) During any period in which the administrative stay of removal is in effect, the alien shall not be removed.
 (4\) Nothing in this subsection may be construed to limit the authority of the Secretary of Homeland Security or the Attorney General to grant a stay of removal or deportation in any case not described in this subsection.
 (
 June 27, 1952, ch. 477, title II, ch. 4, §237, formerly ch. 5, §241,
 66 Stat. 204
 ;
 July 18, 1956, ch. 629, title III, §301(b), (c),
 70 Stat. 575
 ;
 Pub. L. 86–648,
 §9, July 14, 1960,
 74 Stat. 505
 ;
 Pub. L. 87–301,
 §16, Sept. 26, 1961,
 75 Stat. 655
 ;
 Pub. L. 89–236,
 §11(e), Oct. 3, 1965,
 79 Stat. 918
 ;
 Pub. L. 94–571,
 §7(e), Oct. 20, 1976,
 90 Stat. 2706
 ;
 Pub. L. 95–549,
 title I, §103, Oct. 30, 1978,
 92 Stat. 2065
 ;
 Pub. L. 97–116,
 §8, Dec. 29, 1981,
 95 Stat. 1616
 ;
 Pub. L. 99–570,
 title I, §1751(b), Oct. 27, 1986,
 100 Stat. 3207–47
 ;
 Pub. L. 99–603,
 title III, §303(b), Nov. 6, 1986,
 100 Stat. 3431
 ;
 Pub. L. 99–639,
 §2(b), Nov. 10, 1986,
 100 Stat. 3541
 ;
 Pub. L. 99–653,
 §7(c), Nov. 14, 1986,
 100 Stat. 3657
 ;
 Pub. L. 100–525,
 §§2(n)(2\), 9(m), Oct. 24, 1988,
 102 Stat. 2613
 ,
 2620 
 ;
 Pub. L. 100–690,
 title VII, §§7344(a), 7348(a), Nov. 18, 1988,
 102 Stat. 4470
 ,
 4473 
 ;
 Pub. L. 101–649,
 title I, §153(b), title V, §§505(a), 508(a), 544(b), title VI, §602(a), (b), Nov. 29, 1990,
 104 Stat. 5006
 ,
 5050 
 ,
 5051 
 ,
 5061 
 ,
 5077 
 ,
 5081 
 ;
 Pub. L. 102–232,
 title III, §§302(d)(3\), 307(h), (k), Dec. 12, 1991,
 105 Stat. 1745
 ,
 1755 
 ,
 1756 
 ;
 Pub. L. 103–322,
 title XIII, §130003(d), Sept. 13, 1994,
 108 Stat. 2026
 ;
 Pub. L. 103–416,
 title II, §§203(b), 219(g), Oct. 25, 1994,
 108 Stat. 4311
 ,
 4317 
 ;
 Pub. L. 104–132,
 title IV, §§414(a), 435(a), Apr. 24, 1996,
 110 Stat. 1270
 ,
 1274 
 ; renumbered ch. 4, §237, and amended
 Pub. L. 104–208,
 div. C, title I, §108(c), title III, §§301(d), 305(a)(2\), 308(d)(2\), (3\)(A), (e)(1\)(E), (2\)(C), (f)(1\)(L)–(N), (5\), 344(b), 345(b), 347(b), 350(a), 351(b), title VI, §671(a)(4\)(B), (d)(1\)(C), Sept. 30, 1996,
 110 Stat. 3009–558
 ,
 3009\-579 
 ,
 3009\-598 
 ,
 3009\-617 
 ,
 3009\-619 
 to
 3009\-622 
 ,
 3009\-637 
 to
 3009\-640 
 ,
 3009\-721 
 ,
 3009\-723 
 ;
 Pub. L. 106–386,
 div. B, title V, §1505(b)(1\), (c)(2\), Oct. 28, 2000,
 114 Stat. 1525
 ,
 1526 
 ;
 Pub. L. 106–395,
 title II, §201(c)(1\), (2\), Oct. 30, 2000,
 114 Stat. 1634
 ,
 1635 
 ;
 Pub. L. 107–56,
 title IV, §411(b)(1\), Oct. 26, 2001,
 115 Stat. 348
 ;
 Pub. L. 108–458,
 title V, §§5304(b), 5402, 5501(b), 5502(b), Dec. 17, 2004,
 118 Stat. 3736
 ,
 3737 
 ,
 3740 
 ,
 3741 
 ;
 Pub. L. 109–13,
 div. B, title I, §105(a)(1\), (b), May 11, 2005,
 119 Stat. 309
 ,
 310 
 ;
 Pub. L. 109–248,
 title IV, §401, July 27, 2006,
 120 Stat. 622
 ;
 Pub. L. 109–271,
 §6(c), Aug. 12, 2006,
 120 Stat. 763
 ;
 Pub. L. 110–340,
 §2(c), Oct. 3, 2008,
 122 Stat. 3736
 ;
 Pub. L. 110–457,
 title II, §§204, 222(f)(2\), Dec. 23, 2008,
 122 Stat. 5060
 ,
 5071 
 .)
#### **Editorial Notes**
#### References in Text
 This chapter, referred to in subsec. (a)(1\)(B), (G), (3\)(D)(i), was in the original, "this Act", meaning act
 June 27, 1952, ch. 477,
 66 Stat. 163
 , known as the Immigration and Nationality Act, which is classified principally to this chapter. For complete classification of this Act to the Code, see Short Title note set out under
 section 1101 of this title
 and Tables.
 Section 301 of the Immigration Act of 1990, referred to in subsec. (a)(1\)(E)(ii), is section 301 of
 Pub. L. 101–649,
 which is set out as a note under
 section 1255a of this title
 .
 Section 112 of the Immigration Act of 1990, referred to in subsec. (a)(1\)(E)(ii), is section 112 of
 Pub. L. 101–649,
 which is set out as a note under
 section 1153 of this title
 .
 The Military Selective Service Act, referred to in subsec. (a)(2\)(D)(iii), is act
 June 24, 1948, ch. 625,
 62 Stat. 604
 , which was classified principally to section 451 et seq. of the former Appendix to Title 50, War and National Defense, prior to editorial reclassification and renumbering as
 chapter 49 (§3801 et seq.) of Title 50
 . For complete classification of this Act to the Code, see Tables.
 The Trading With the Enemy Act, referred to in subsec. (a)(2\)(D)(iii), is act
 Oct. 6, 1917, ch. 106,
 40 Stat. 411
 , which was classified to sections 1 to 6, 7 to 39 and 41 to 44 of the former Appendix to Title 50, War and National Defense, prior to editorial reclassification and renumbering as
 chapter 53 (§4301 et seq.) of Title 50
 . For complete classification of this Act to the Code, see Tables.
 The Alien Registration Act, 1940, referred to in subsec. (a)(3\)(B)(i), is act
 June 28, 1940, ch. 439,
 54 Stat. 670
 . Section 36(a) of that act was classified to
 section 457(c) of this title
 and was repealed by section 403(a)(39\) of act June 27, 1952\.
 The Foreign Agents Registration Act of 1938, referred to in subsec. (a)(3\)(B)(ii), is act
 June 8, 1938, ch. 327,
 52 Stat. 631
 , which is classified generally to subchapter II (§611 et seq.) of
 chapter 11 of Title 22
 , Foreign Relations and Intercourse. For complete classification of this Act to the Code, see Short Title note set out under
 section 611 of Title 22
 and Tables.
 Section was formerly classified to
 section 1251 of this title
 prior to renumbering by
 Pub. L. 104–208
 .
#### Prior Provisions
 A prior section 1227, acts
 June 27, 1952, ch. 477, title II, ch. 4, §237,
 66 Stat. 201
 ; Dec. 29, 1981,
 Pub. L. 97–116,
 §7,
 95 Stat. 1615
 ; Oct. 18, 1986,
 Pub. L. 99–500,
 §101(b) \[title II, §206(b)(2\)], as added Oct. 24, 1988,
 Pub. L. 100–525,
 §4(b)(4\),
 102 Stat. 2615
 ; Oct. 24, 1988,
 Pub. L. 100–525,
 §9(l),
 102 Stat. 2620
 ; Nov. 29, 1990,
 Pub. L. 101–649,
 title V, §543(a)(2\),
 104 Stat. 5057
 ; Dec. 12, 1991,
 Pub. L. 102–232,
 title III, §306(c)(4\)(B),
 105 Stat. 1752
 ; Apr. 24, 1996,
 Pub. L. 104–132,
 title IV, §422(b),
 110 Stat. 1272
 ; Sept. 30, 1996,
 Pub. L. 104–208,
 div. C, title III, §308(d)(5\),
 110 Stat. 3009–619
 , related to immediate deportation of aliens excluded from admission or entering in violation of law, prior to repeal by
 Pub. L. 104–208,
 div. C, title III, §§305(a)(1\), 309, Sept. 30, 1996,
 110 Stat. 3009–597
 ,
 3009\-625 
 , effective, with certain transitional provisions, on the first day of the first month beginning more than 180 days after Sept. 30, 1996\. See
 section 1231 of this title
 .
#### Amendments
**2008** 
 \-Subsec. (a)(2\)(F).
 Pub. L. 110–457,
 §222(f)(2\), added subpar. (F).
 Subsec. (a)(4\)(F).
 Pub. L. 110–340
 added subpar. (F).
 Subsec. (d).
 Pub. L. 110–457,
 §204, added subsec. (d).
**2006** 
 \-Subsec. (a)(1\)(H)(ii).
 Pub. L. 109–271
 amended cl. (ii) generally. Prior to amendment, cl. (ii) read as follows: "is an alien who qualifies for classification under clause (iii) or (iv) of
 section 1154(a)(1\)(A) of this title
 or clause (ii) or (iii) of
 section 1154(a)(1\)(B) of this title
 ."
 Subsec. (a)(2\)(A)(v), (vi).
 Pub. L. 109–248
 added cl. (v) and redesignated former cl. (v) as (vi).
**2005** 
 \-Subsec. (a)(4\)(B).
 Pub. L. 109–13,
 §105(a)(1\), reenacted heading without change and amended text generally. Prior to amendment, text read as follows: "Any alien who has engaged, is engaged, or at any time after admission engages in any terrorist activity (as defined in
 section 1182(a)(3\)(B)(iv) of this title
 ) is deportable."
 Subsec. (a)(4\)(E).
 Pub. L. 109–13,
 §105(b), repealed
 Pub. L. 108–458,
 §5402\. See 2004 Amendment note below.
**2004** 
 \-Subsec. (a)(1\)(B).
 Pub. L. 108–458,
 §5304(b), substituted "United States, or whose nonimmigrant visa (or other documentation authorizing admission into the United States as a nonimmigrant) has been revoked under
 section 1201(i) of this title
 , is" for "United States is".
 Subsec. (a)(4\)(D).
 Pub. L. 108–458,
 §5501(b), substituted "Participated in Nazi persecution, genocide, or the commission of any act of torture or extrajudicial killing" for "Assisted in Nazi persecution or engaged in genocide" in heading and "clause (i), (ii), or (iii)" for "clause (i) or (ii)" in text.
 Subsec. (a)(4\)(E).
 Pub. L. 108–458,
 §5502(b), added subpar. (E) relating to participation in the commission of severe violations of religious freedom.
 Pub. L. 108–458,
 §5402, which added subpar. (E) relating to recipient of military\-type training, was repealed by
 Pub. L. 109–13,
 §105(b). See Effective Date of 2005 Amendment note below.
**2001** 
 \-Subsec. (a)(4\)(B).
 Pub. L. 107–56
 substituted "
 section 1182(a)(3\)(B)(iv) of this title
 " for "
 section 1182(a)(3\)(B)(iii) of this title
 ".
**2000** 
 \-Subsec. (a)(1\)(H).
 Pub. L. 106–386,
 §1505(c)(2\), redesignated cls. (i) and (ii) as subcls. (I) and (II), respectively, of cl. (i), and added cl. (ii).
 Subsec. (a)(3\)(D).
 Pub. L. 106–395,
 §201(c)(2\), amended heading and text of subpar. (D) generally. Prior to amendment, text read as follows: "Any alien who falsely represents, or has falsely represented, himself to be a citizen of the United States for any purpose or benefit under this chapter (including
 section 1324a of this title
 ) or any Federal or State law is deportable."
 Subsec. (a)(6\).
 Pub. L. 106–395,
 §201(c)(1\), amended heading and text of par. (6\) generally. Prior to amendment, text read as follows: "Any alien who has voted in violation of any Federal, State, or local constitutional provision, statute, ordinance, or regulation is deportable."
 Subsec. (a)(7\).
 Pub. L. 106–386,
 §1505(b)(1\), added par. (7\).
**1996** 
 \-Subsec. (a).
 Pub. L. 104–208,
 §308(e)(2\)(C), substituted "removed" for "deported" in introductory provisions.
 Pub. L. 104–208,
 §301(d)(1\), substituted "in and admitted to the United States" for "in the United States" in introductory provisions.
 Subsec. (a)(1\).
 Pub. L. 104–208,
 §301(d)(2\), substituted "Inadmissible" for "Excludable" in par. heading.
 Subsec. (a)(1\)(A).
 Pub. L. 104–208,
 §§301(d)(3\), 308(d)(3\)(A), amended subpar. (A) identically, substituting "inadmissible" for "excludable".
 Pub. L. 104–208,
 §301(d)(2\), substituted "Inadmissible" for "Excludable" in subpar. heading.
 Subsec. (a)(1\)(B).
 Pub. L. 104–208,
 §301(d)(4\), amended heading and text of subpar. (B) generally. Prior to amendment, text read as follows: "Any alien who entered the United States without inspection or at any time or place other than as designated by the Attorney General or is in the United States in violation of this chapter or any other law of the United States is deportable."
 Subsec. (a)(1\)(E)(iii).
 Pub. L. 104–208,
 §351(b), inserted "an individual who at the time of the offense was" after "aided only".
 Subsec. (a)(1\)(F).
 Pub. L. 104–208,
 §671(d)(1\)(C), struck out heading and text of subpar. (F). Text read as follows: "Any alien who obtains the status of an alien lawfully admitted for temporary residence under
 section 1161 of this title
 who fails to meet the requirement of
 section 1161(d)(5\)(A) of this title
 by the end of the applicable period is deportable."
 Subsec. (a)(1\)(G).
 Pub. L. 104–208,
 §308(f)(1\)(L), substituted "admission" for "entry" wherever appearing.
 Subsec. (a)(1\)(H).
 Pub. L. 104–208,
 §308(f)(5\), which directed amendment of subsec. (a)(1\)(H)(ii) by striking "at entry", was executed by striking "at entry" after "grounds of inadmissibility" in concluding provisions of subpar. (H) to reflect the probable intent of Congress.
 Pub. L. 104–208,
 §308(f)(1\)(M), substituted "admission as aliens" for "entry as aliens" in introductory provisions and "such admission" for "such entry" in cl. (ii).
 Pub. L. 104–208,
 §308(e)(1\)(E), substituted "removal" for "deportation" wherever appearing.
 Pub. L. 104–208,
 §308(d)(2\)(A), (3\)(A), amended subpar. (H) identically, substituting "inadmissible" for "excludable" in introductory provisions.
 Subsec. (a)(2\)(A)(i)(I).
 Pub. L. 104–208,
 §671(a)(4\)(B), substituted "1255(j)" for "1255(i)".
 Pub. L. 104–208,
 §308(f)(1\)(N), substituted "admission" for "entry".
 Subsec. (a)(2\)(A)(i)(II).
 Pub. L. 104–132,
 §435(a), amended subcl. (II) generally. Prior to amendment, subcl. (II) read as follows: "either is sentenced to confinement or is confined therefor in a prison or correctional institution for one year or longer,".
 Subsec. (a)(2\)(A)(ii), (iii).
 Pub. L. 104–208,
 §308(f)(1\)(N), substituted "admission" for "entry".
 Subsec. (a)(2\)(A)(iv).
 Pub. L. 104–208,
 §108(c)(2\), added cl. (iv). Former cl. (iv) redesignated (v).
 Subsec. (a)(2\)(A)(v).
 Pub. L. 104–208,
 §108(c)(3\), substituted "(iii), and (iv)" for "and (iii)".
 Pub. L. 104–208,
 §108(c)(1\), redesignated cl. (iv) as (v).
 Subsec. (a)(2\)(B).
 Pub. L. 104–208,
 §308(f)(1\)(N), substituted "admission" for "entry" in cls. (i) and (ii).
 Subsec. (a)(2\)(C).
 Pub. L. 104–208,
 §308(f)(1\)(N), substituted "admission" for "entry".
 Subsec. (a)(2\)(E).
 Pub. L. 104–208,
 §350(a), added subpar. (E).
 Subsec. (a)(2\)(E)(i), (ii).
 Pub. L. 104–208,
 §308(f)(1\)(N), substituted "admission" for "entry".
 Subsec. (a)(3\)(C).
 Pub. L. 104–208,
 §345(b), amended heading and text of subpar. (C) generally. Prior to amendment, text read as follows: "Any alien who is the subject of a final order for violation of
 section 1324c of this title
 is deportable."
 Subsec. (a)(3\)(D).
 Pub. L. 104–208,
 §344(b), added subpar. (D).
 Subsec. (a)(4\)(A), (B).
 Pub. L. 104–208,
 §308(f)(1\)(N), substituted "admission" for "entry".
 Subsec. (a)(4\)(C)(ii).
 Pub. L. 104–208,
 §308(d)(2\)(B), substituted "inadmissibility" for "excludability".
 Subsec. (a)(6\).
 Pub. L. 104–208,
 §347(b), added par. (6\).
 Subsec. (c).
 Pub. L. 104–208,
 §308(d)(2\)(C), substituted "inadmissibility" for "exclusion".
 Subsec. (d).
 Pub. L. 104–208,
 §308(d)(2\)(D), struck out subsec. (d) which read as follows: "Notwithstanding any other provision of this subchapter, an alien found in the United States who has not been admitted to the United States after inspection in accordance with
 section 1225 of this title
 is deemed for purposes of this chapter to be seeking entry and admission to the United States and shall be subject to examination and exclusion by the Attorney General under part IV of this subchapter. In the case of such an alien the Attorney General shall provide by regulation an opportunity for the alien to establish that the alien was so admitted."
 Pub. L. 104–132,
 §414(a), added subsec. (d).
**1994** 
 \-Subsec. (a)(2\)(A)(i)(I).
 Pub. L. 103–322
 inserted "(or 10 years in the case of an alien provided lawful permanent resident status under
 section 1255(i) of this title
 )" after "five years".
 Subsec. (a)(2\)(C).
 Pub. L. 103–416,
 §203(b)(1\), substituted ", or of attempting or conspiring to purchase, sell, offer for sale, exchange, use, own, possess, or carry," for "in violation of any law," and inserted "in violation of any law" after "title 18\)".
 Subsec. (a)(3\)(B)(ii), (iii).
 Pub. L. 103–416,
 §203(b)(2\), inserted "an attempt or" before "a conspiracy".
 Subsec. (c).
 Pub. L. 103–416,
 §219(g), substituted "and (3\)(A) of subsection (a)" for "or (3\)(A) of subsection (a)".
**1991** 
 \-Subsec. (a).
 Pub. L. 102–232,
 §307(h)(1\), substituted "if the alien is within one or more of the following classes of deportable aliens" for "if the alien is deportable as being within one or more of the following classes of aliens".
 Subsec. (a)(1\)(D)(i).
 Pub. L. 102–232,
 §307(h)(2\), inserted "respective" after "terminated under such".
 Subsec. (a)(1\)(E)(i).
 Pub. L. 102–232,
 §307(h)(3\), inserted "any" after "at the time of" and after "within 5 years of the date of" in parenthetical provision.
 Subsec. (a)(1\)(E)(ii), (iii).
 Pub. L. 102–232,
 §307(h)(4\), added cl. (ii) and redesignated former cl. (ii) as (iii).
 Subsec. (a)(1\)(G).
 Pub. L. 102–232,
 §307(h)(5\), substituted "section 1182(a)(6\)(C)(i)" for "section 1182(a)(5\)(C)(i)".
 Subsec. (a)(1\)(H).
 Pub. L. 102–232,
 §307(h)(6\), substituted "paragraph (4\)(D)" for "paragraph (6\) or (7\)".
 Subsec. (a)(2\)(D).
 Pub. L. 102–232,
 §307(h)(7\), inserted "or attempt" after "conspiracy".
 Subsec. (a)(3\)(C).
 Pub. L. 102–232,
 §307(h)(8\), added subpar. (C).
 Subsec. (a)(4\)(A), (B).
 Pub. L. 102–232,
 §307(h)(9\), substituted "after entry engages" for "after entry has engaged".
 Subsec. (a)(4\)(C).
 Pub. L. 102–232,
 §307(h)(10\), substituted "excludability" for "excluability".
 Subsec. (c).
 Pub. L. 102–232,
 §307(k)(2\), redesignated subsec. (h) as (c) and substituted "existed" for "exist".
 Subsec. (d).
 Pub. L. 102–232,
 §307(k)(1\), struck out subsec. (d) which related to applicability of this section to aliens belonging to any of the classes enumerated in subsection (a) of this section.
 Subsec. (h).
 Pub. L. 102–232,
 §307(k)(2\), redesignated subsec. (h) as (c).
 Pub. L. 102–232,
 §302(d)(3\), struck out comma after "(3\)(A)".
**1990** 
 \-Subsec. (a).
 Pub. L. 101–649,
 §602(a), amended subsec. (a) generally, consolidating 20 categories of excludable aliens into 5 broader classes.
 Pub. L. 101–649,
 §544(b), added par. (21\) which read as follows: "is the subject of a final order for violation of
 section 1324c of this title
 ."
 Pub. L. 101–649,
 §508(a), substituted "conspiracy or attempt" for "conspiracy" in par. (11\).
 Subsec. (b).
 Pub. L. 101–649,
 §602(b), redesignated subsec. (e) as (b), substituted "paragraph (4\) of subsection (a)" for "subsection (a)(6\) or (7\) of this section" and struck out former subsec. (b) which related to nonapplicability of subsec. (a)(4\) of this section.
 Pub. L. 101–649,
 §505(a), struck out "(1\)" after "crimes shall not apply" and ", or (2\) if the court sentencing such alien for such crime shall make, at the time of first imposing judgment or passing sentence, or within thirty days thereafter, a recommendation to the Attorney General that such alien not be deported, due notice having been given prior to making such recommendation to representatives of the interested State, the Service, and prosecution authorities, who shall be granted an opportunity to make representations in the matter" at end of first sentence, and inserted "or who has been convicted of an aggravated felony" after "subsection (a)(11\) of this section" in second sentence.
 Subsec. (c).
 Pub. L. 101–649,
 §602(b)(1\), struck out subsec. (c) which related to fraudulent entry.
 Subsec. (e).
 Pub. L. 101–649,
 §602(b)(2\)(B), redesignated subsec. (e) as (b).
 Subsecs. (f), (g).
 Pub. L. 101–649,
 §602(b)(1\), struck out subsecs. (f) and (g) which related to waiver of deportation in specified cases and hardship waivers, respectively.
 Subsec. (h).
 Pub. L. 101–649,
 §153(b)(2\), amended subsec. (h) generally. Prior to amendment, subsec. (h) read as follows: "Paragraphs (1\), (2\), (5\), (9\), or (12\) of subsection (a) of this section (other than so much of paragraph (1\) as relates to a ground of exclusion described in paragraph (9\), (10\), (23\), (27\), (29\), or (33\) of
 section 1182(a) of this title
 ) shall not apply to a special immigrant described in
 section 1101(a)(27\)(J) of this title
 based upon circumstances that exist before the date the alien was provided such special immigrant status."
 Pub. L. 101–649,
 §153(b)(1\), added subsec. (h).
**1988** 
 \-Subsec. (a)(4\).
 Pub. L. 100–690,
 §7344(a), inserted cl. (B).
 Subsec. (a)(14\).
 Pub. L. 100–690
 inserted "any firearm or destructive device (as defined in paragraphs (3\) and (4\)), respectively, of
 section 921(a) of title 18
 , or any revolver or" after "law".
 Subsec. (a)(17\).
 Pub. L. 100–525,
 §9(m), substituted "amendment, thereof, known as the Trading With the Enemy Act" for "amendment thereof; the Trading With the Enemy Act".
 Subsec. (a)(20\).
 Pub. L. 100–525,
 §2(n)(2\), substituted "an alien lawfully admitted" for "an alien who becomes lawfully admitted".
**1986** 
 \-Subsec. (a)(9\).
 Pub. L. 99–639,
 §2(b)(1\), designated existing provisions as cl. (A) and added cl. (B).
 Subsec. (a)(10\).
 Pub. L. 99–653
 repealed par. (10\). Prior to repeal, par. (10\) read as follows: "entered the United States from foreign contiguous territory or adjacent islands, having arrived there on a vessel or aircraft of a nonsignatory transportation company under
 section 1228(a) of this title
 and was without the required period of stay in such foreign contiguous territory or adjacent islands following such arrival (other than an alien described in
 section 1101(a)(27\)(A) of this title
 and aliens born in the Western Hemisphere);".
 Subsec. (a)(11\).
 Pub. L. 99–570
 substituted "any law or regulation of a State, the United States, or a foreign country relating to a controlled substance (as defined in
 section 802 of title 21
 )" for "any law or regulation relating to the illicit possession of or traffic in narcotic drugs or marihuana, or who has been convicted of a violation of, or a conspiracy to violate, any law or regulation governing or controlling the taxing, manufacture, production, compounding, transportation, sale, exchange, dispensing, giving away, importation, exportation, or the possession for the purpose of the manufacture, production, compounding, transportation, sale, exchange, dispensing, giving away, importation, or exportation of opium, coca leaves, heroin, marihuana, any salt derivative or preparation of opium or coca leaves or isonipecaine or any addiction\-forming or addiction\-sustaining opiate".
 Subsec. (a)(20\).
 Pub. L. 99–603
 added par. (20\).
 Subsec. (g).
 Pub. L. 99–639,
 §2(b)(2\), added subsec. (g).
**1981** 
 \-Subsec. (f).
 Pub. L. 97–116
 designated existing provision as par. (1\)(A), substituted provision authorizing discretionary waiver of deportation based on visa fraud or misrepresentation in the case of an alien, other than an alien described in subsec. (a)(19\) of this section, who is the spouse, parent, or child of a citizen of the United States or of an alien lawfully admitted to the United States for permanent residence and who was in possession of an immigrant visa or equivalent document and was otherwise admissible to the United States at the time of such entry except for those grounds specified in
 section 1182(a)(14\), (20\), and (21\) of this title
 which were a direct result of that fraud or misrepresentation, with relief available to those who have made innocent, as well as fraudulent, misrepresentations, for provision requiring mandatory waiver of deportation based on visa fraud or misrepresentation at the time of entry in the case of an alien who is the spouse, parent, or child of a United States citizen or of an alien lawfully admitted for permanent residence who is otherwise admissible, and added pars. (1\)(B) and (2\).
**1978** 
 \-Subsec. (a)(19\).
 Pub. L. 95–549
 added par. (19\).
**1976** 
 \-Subsec. (a)(10\).
 Pub. L. 94–571
 substituted "(other than an alien described in
 section 1101(a)(27\)(A) of this title
 and aliens born in the Western Hemisphere)" for "(other than an alien who is a native\-born citizen of any of the countries enumerated in
 section 1101(a)(27\)(A) of this title
 and an alien described in
 section 1101(a)(27\)(B) of this title
 )".
**1965** 
 \-Subsec. (a)(10\).
 Pub. L. 89–236
 substituted "
 section 1101(a)(27\)(A) of this title
 " for "
 section 1101(a)(27\)(C) of this title
 ".
**1961** 
 \-Subsec. (f).
 Pub. L. 87–301
 added subsec. (f).
**1960** 
 \-Subsec. (a)(11\).
 Pub. L. 86–648
 inserted "or marihuana" after "narcotic drugs".
**1956** 
 \-Subsec. (a)(11\). Act July 18, 1956, §301(b), included conspiracy to violate any narcotic law, and the illicit possession of narcotics, as additional grounds for deportation.
 Subsec. (b). Act July 18, 1956, §301(c), inserted at end "The provisions of this subsection shall not apply in the case of any alien who is charged with being deportable from the United States under subsection (a)(11\) of this section."
#### **Statutory Notes and Related Subsidiaries**
#### Effective Date of 2008 Amendment
 Amendment by
 Pub. L. 110–340
 applicable to offenses committed before, on, or after Oct. 3, 2008, see section 3(c) of
 Pub. L. 111–122,
 set out as a note under
 section 1182 of this title
 .
#### Effective Date of 2005 Amendment
Pub. L. 109–13,
 div. B, title I, §105(a)(2\), May 11, 2005,
 119 Stat. 309
 , provided that: "The amendment made by paragraph (1\) \[amending this section] shall take effect on the date of the enactment of this division \[May 11, 2005], and the amendment, and section 237(a)(4\)(B) of the Immigration and Nationality Act (
 8 U.S.C. 1227(a)(4\)(B)
 ), as amended by such paragraph, shall apply to\-
 "(A) removal proceedings instituted before, on, or after the date of the enactment of this division \[May 11, 2005]; and
 "(B) acts and conditions constituting a ground for inadmissibility, excludability, deportation, or removal occurring or existing before, on, or after such date."
Pub. L. 109–13,
 div. B, title I, §105(b), May 11, 2005,
 119 Stat. 310
 , provided that: "Effective as of the date of the enactment of the Intelligence Reform and Terrorism Prevention Act of 2004 (
 Public Law 108–458
 ) \[Dec. 17, 2004], section 5402 of such Act \[amending this section] is repealed, and the Immigration and Nationality Act \[
 8 U.S.C. 1101 et seq.
 ] shall be applied as if such section had not been enacted."
#### Effective Date of 2004 Amendment
 Amendment by section 5304(b) of
 Pub. L. 108–458
 effective Dec. 17, 2004, and applicable to revocations under
 sections 1155 and 1201(i) of this title
 made before, on, or after such date, see section 5304(d) of
 Pub. L. 108–458,
 set out as a note under
 section 1155 of this title
 .
 Amendment by section 5501(b) of
 Pub. L. 108–458
 applicable to offenses committed before, on, or after Dec. 17, 2004, see section 5501(c) of
 Pub. L. 108–458,
 set out as a note under
 section 1182 of this title
 .
#### Effective Date of 2001 Amendment
 Amendment by
 Pub. L. 107–56
 effective Oct. 26, 2001, and applicable to actions taken by an alien before, on, or after Oct. 26, 2001, and to all aliens, regardless of date of entry or attempted entry into the United States, in removal proceedings on or after such date (except for proceedings in which there has been a final administrative decision before such date) or seeking admission to the United States on or after such date, with special rules and exceptions, see section 411(c) of
 Pub. L. 107–56,
 set out as a note under
 section 1182 of this title
 .
#### Effective Date of 2000 Amendment
Pub. L. 106–395,
 title II, §201(c)(3\), Oct. 30, 2000,
 114 Stat. 1635
 , provided that: "The amendment made by paragraph (1\) \[amending this section] shall be effective as if included in the enactment of section 347 of the Illegal Immigration Reform and Immigrant Responsibility Act of 1996 (
 Public Law 104–208
 ;
 110 Stat. 3009–638
 ) and shall apply to voting occurring before, on, or after September 30, 1996\. The amendment made by paragraph (2\) \[amending this section] shall be effective as if included in the enactment of section 344 of the Illegal Immigration Reform and Immigrant Responsibility Act of 1996 (
 Public Law 104–208
 ;
 110 Stat. 3009–637
 ) and shall apply to representations made on or after September 30, 1996\. Such amendments shall apply to individuals in proceedings under the Immigration and Nationality Act \[
 8 U.S.C. 1101 et seq.
 ] on or after September 30, 1996\."
#### Effective Date of 1996 Amendments
 Amendment by sections 301(d), 305(a)(2\), and 308(d)(2\)(A)–(C), (3\)(A), (e)(1\)(E), (2\)(C), (f)(1\)(L)–(N), (5\) of
 Pub. L. 104–208
 effective, with certain transitional provisions, on the first day of the first month beginning more than 180 days after Sept. 30, 1996, see section 309 of
 Pub. L. 104–208,
 set out as a note under
 section 1101 of this title
 .
Pub. L. 104–208,
 div. C, title III, §308(d)(2\)(D), Sept. 30, 1996,
 110 Stat. 3009–617
 , provided that the amendment made by section 308(d)(2\)(D) is effective Sept. 30, 1996\.
 Amendment by section 344(b) of
 Pub. L. 104–208
 applicable to representations made on or after Sept. 30, 1996, see section 344(c) of
 Pub. L. 104–208,
 set out as a note under
 section 1182 of this title
 .
 Amendment by section 347(b) of
 Pub. L. 104–208
 applicable to voting occurring before, on, or after Sept. 30, 1996, see section 347(c) of
 Pub. L. 104–208,
 set out as a note under
 section 1182 of this title
 .
Pub. L. 104–208,
 div. C, title III, §350(b), Sept. 30, 1996,
 110 Stat. 3009–640
 , provided that: "The amendment made by subsection (a) \[amending this section] shall apply to convictions, or violations of court orders, occurring after the date of the enactment of this Act \[Sept. 30, 1996]."
 Amendment by section 351(b) of
 Pub. L. 104–208
 applicable to applications for waivers filed before, on, or after Sept. 30, 1996, but not applicable to such an application for which a final determination has been made as of Sept. 30, 1996, see section 351(c) of
 Pub. L. 104–208,
 set out as a note under
 section 1182 of this title
 .
 Amendment by section 671(a)(4\)(B) of
 Pub. L. 104–208
 effective as if included in the enactment of the Violent Crime Control and Law Enforcement Act of 1994,
 Pub. L. 103–322,
 see section 671(a)(7\) of
 Pub. L. 104–208,
 set out as a note under
 section 1101 of this title
 .
Pub. L. 104–132,
 title IV, §414(b), Apr. 24, 1996,
 110 Stat. 1270
 , provided that: "The amendment made by subsection (a) \[amending this section] shall take effect on the first day of the first month beginning more than 180 days after the date of the enactment of this Act \[Apr. 24, 1996]."
Pub. L. 104–132,
 title IV, §435(b), Apr. 24, 1996,
 110 Stat. 1275
 , provided that: "The amendment made by subsection (a) \[amending this section] shall apply to aliens against whom deportation proceedings are initiated after the date of the enactment of this Act \[Apr. 24, 1996]."
#### Effective Date of 1994 Amendment
 Amendment by section 203(b) of
 Pub. L. 103–416
 applicable to convictions occurring before, on, or after Oct. 25, 1994, see section 203(c) of
 Pub. L. 103–416,
 set out as an Effective and Termination Dates of 1994 Amendments note under
 section 1182 of this title
 .
 Amendment by section 219(g) of
 Pub. L. 103–416
 effective as if included in the enactment of the Immigration Act of 1990,
 Pub. L. 101–649,
 see section 219(dd) of
 Pub. L. 103–416,
 set out as a note under
 section 1101 of this title
 .
#### Effective Date of 1991 Amendment
 Amendment by sections 302(d)(3\), 307(h) of
 Pub. L. 102–232
 effective as if included in the enactment of the Immigration Act of 1990,
 Pub. L. 101–649,
 see section 310(1\) of
 Pub. L. 102–232,
 set out as a note under
 section 1101 of this title
 .
Pub. L. 102–232,
 title III, §307(k), Dec. 12, 1991,
 105 Stat. 1756
 , provided that the amendment made by section 307(k) is effective as if included in section 602(b) of the Immigration Act of 1990,
 Pub. L. 101–649
 .
#### Effective Date of 1990 Amendment
 Amendment by section 153(b)(1\) of
 Pub. L. 101–649
 effective Nov. 29, 1990, and (unless otherwise provided) applicable to fiscal year 1991, see section 161(b) of
 Pub. L. 101–649,
 set out as a note under
 section 1101 of this title
 .
Pub. L. 101–649,
 title I, §153(b)(2\), Nov. 29, 1990,
 104 Stat. 5006
 , provided that the amendment of subsec. (h) as added by section 153(b)(1\) of
 Pub. L. 101–649
 is effective on the date that the amendments made by section 602 of
 Pub. L. 101–649
 become effective. See section 602(d) of
 Pub. L. 101–649,
 set out below.
Pub. L. 101–649,
 title V, §505(b), Nov. 29, 1990,
 104 Stat. 5050
 , provided that: "The amendments made by subsection (a) \[amending this section] shall take effect on the date of the enactment of this Act \[Nov. 29, 1990] and shall apply to convictions entered before, on, or after such date."
Pub. L. 101–649,
 title V, §508(b), Nov. 29, 1990,
 104 Stat. 5051
 , provided that: "The amendment made by subsection (a) \[amending this section] shall apply to convictions occurring on or after the date of the enactment of this Act \[Nov. 29, 1990]."
Pub. L. 101–649,
 title V, §544(d), formerly §544(c), Nov. 29, 1990,
 104 Stat. 5061
 , as redesignated by
 Pub. L. 102–232,
 title III, §306(c)(5\)(B), Dec. 12, 1991,
 105 Stat. 1752
 , provided that: "The amendments made by this section \[enacting
 section 1324c of this title
 and amending this section] shall apply to persons or entities that have committed violations on or after the date of the enactment of this Act \[Nov. 29, 1990]."
Pub. L. 101–649,
 title VI, §602(d), Nov. 29, 1990,
 104 Stat. 5082
 , provided that: "The amendments made by this section, and by section 603(b) of this Act \[amending this section,
 sections 1161, 1252, 1253, and 1254 of this title
 , and
 section 402 of Title 42
 , The Public Health and Welfare], shall not apply to deportation proceedings for which notice has been provided to the alien before March 1, 1991\."
#### Effective Date of 1988 Amendments
Pub. L. 100–690,
 title VII, §7344(b), Nov. 18, 1988,
 102 Stat. 4471
 , provided that: "The amendments made by subsection (a) \[amending this section] shall apply to any alien who has been convicted, on or after the date of the enactment of this Act \[Nov. 18, 1988], of an aggravated felony."
Pub. L. 100–690,
 title VII, §7348(b), Nov. 18, 1988,
 102 Stat. 4473
 , provided that: "The amendment made by subsection (a) \[amending this section] shall apply to any alien convicted, on or after the date of the enactment of this Act \[Nov. 18, 1988], of possessing any firearm or destructive device referred to in such subsection."
 Amendment by section 2(n)(2\) of
 Pub. L. 100–525
 effective as if included in enactment of Immigration Reform and Control Act of 1986,
 Pub. L. 99–603,
 see section 2(s) of
 Pub. L. 100–525,
 set out as a note under
 section 1101 of this title
 .
#### Effective Date of 1986 Amendments
 Amendment by
 Pub. L. 99–653
 applicable to visas issued, and admissions occurring, on or after Nov. 14, 1986, see section 23(a) of
 Pub. L. 99–653,
 set out as a note under
 section 1101 of this title
 .
 Amendment by
 Pub. L. 99–570
 applicable to convictions occurring before, on, or after Oct. 27, 1986, see section 1751(c) of
 Pub. L. 99–570,
 set out as a note under
 section 1182 of this title
 .
#### Effective Date of 1981 Amendment
 Amendment by
 Pub. L. 97–116
 effective Dec. 29, 1981, see section 21(a) of
 Pub. L. 97–116,
 set out as a note under
 section 1101 of this title
 .
#### Effective Date of 1976 Amendment
 Amendment by
 Pub. L. 94–571
 effective on first day of first month which begins more than sixty days after Oct. 20, 1976, see section 10 of
 Pub. L. 94–571,
 set out as a note under
 section 1101 of this title
 .
#### Effective Date of 1965 Amendment
 For effective date of amendment by
 Pub. L. 89–236
 see section 20 of
 Pub. L. 89–236,
 set out as a note under
 section 1151 of this title
 .
#### Effective Date of 1956 Amendment
 Amendment by act July 18, 1956, effective July 19, 1956, see section 401 of act July 18, 1956\.
#### Savings Provision
Pub. L. 101–649,
 title VI, §602(c), Nov. 29, 1990,
 104 Stat. 5081
 , provided that: "Notwithstanding the amendments made by this section \[amending this section], any alien who was deportable because of a conviction (before the date of the enactment of this Act \[Nov. 29, 1990]) of an offense referred to in paragraph (15\), (16\), (17\), or (18\) of section 241(a) \[now 237] of the Immigration and Nationality Act \[
 8 U.S.C. 1227
 ], as in effect before the date of the enactment of this Act, shall be considered to remain so deportable. Except as otherwise specifically provided in such section and subsection (d) \[set out as a note above], the provisions of such section, as amended by this section, shall apply to all aliens described in subsection (a) thereof notwithstanding that (1\) any such alien entered the United States before the date of the enactment of this Act, or (2\) the facts, by reason of which an alien is described in such subsection, occurred before the date of the enactment of this Act."
#### Abolition of Immigration and Naturalization Service and Transfer of Functions
 For abolition of Immigration and Naturalization Service, transfer of functions, and treatment of related references, see note set out under
 section 1551 of this title
 .
#### Report on Criminal Aliens
Pub. L. 101–649,
 title V, §510, Nov. 29, 1990,
 104 Stat. 5051
 , as amended by
 Pub. L. 102–232,
 title III, §306(a)(8\), (9\), Dec. 12, 1991,
 105 Stat. 1751
 , provided that the Attorney General was to submit to appropriate Committees of Congress, by not later than Dec. 1, 1991, a report describing efforts of Immigration and Naturalization Service to identify, apprehend, detain, and remove from the United States aliens who have been convicted of crimes in the United States and including a criminal alien census and removal plan.
1 
 So in original. No cl. (ii) has been enacted. 
2 
 So in original. Probably should be "in". 
