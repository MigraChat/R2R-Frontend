<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1432&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:57
-->
### §1432\. Repealed.
 Pub. L. 106–395,
 title I, §103(a), Oct. 30, 2000,
 114 Stat. 1632
 Section, acts
 June 27, 1952, ch. 477, title III, ch. 2, §321,
 66 Stat. 245
 ;
 Pub. L. 95–417,
 §5, Oct. 5, 1978,
 92 Stat. 918
 ;
 Pub. L. 97–116,
 §18(m), Dec. 29, 1981,
 95 Stat. 1620
 ;
 Pub. L. 99–653,
 §15, Nov. 14, 1986,
 100 Stat. 3658
 ;
 Pub. L. 100–525,
 §8(l), Oct. 24, 1988,
 102 Stat. 2618
 , related to conditions for automatic citizenship of children born outside the United States of alien parents.
#### **Statutory Notes and Related Subsidiaries**
#### Effective Date of Repeal
 Repeal effective 120 days after Oct. 30, 2000, see section 104 of
 Pub. L. 106–395,
 set out as an Effective Date of 2000 Amendment note under
 section 1431 of this title
 .
