<!--
url: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title8-section1359&num=0&edition=prelim
date_accessed: 2024-07-28 23:45:48
-->
### §1359\. Application to American Indians born in Canada
 Nothing in this subchapter shall be construed to affect the right of American Indians born in Canada to pass the borders of the United States, but such right shall extend only to persons who possess at least 50 per centum of blood of the American Indian race.
 (
 June 27, 1952, ch. 477, title II, ch. 9, §289,
 66 Stat. 234
 .)
